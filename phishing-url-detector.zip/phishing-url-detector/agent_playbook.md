# Agent Playbook for Phishing URL Detector

This playbook lists the steps an automation agent should perform to keep this repository healthy and up to date.

1. **Validate the workflow:** Check that `flows/phishing-url-detector.json` is valid n8n JSON and imports without errors.
2. **Lint & test:** Run any available linters on Markdown and JSON files. Ensure that `README.md` includes the Quick Start and diagram and that `.env.sample` lists all required variables.
3. **Generate artefacts:** Optionally run the workflow in a test environment to produce example outputs (Slack messages) and update the `/examples/` folder.
4. **Update documentation:** If the workflow changes, regenerate `assets/phishing-detector-diagram.png` and update the scoring description in the README.
5. **Open issues:** Create GitHub issues for any missing pieces (e.g. missing demo GIF, outdated dependencies).

### Phishing URL Detector TODOs

This issue collects the remaining tasks to polish this repository for Agent Mode deployment:

- [ ] **Export workflow JSON:** Commit the n8n export at `flows/phishing-url-detector.json` so others can import the workflow directly.
- [ ] **Add diagram:** Include `assets/phishing-detector-diagram.png` and embed it in the README to visualise the flow.
- [ ] **Environment sample:** Ship a `.env.sample` file listing required variables (`VT_API_KEY`, `SLACK_WEBHOOK_URL`).
- [ ] **Quick Start instructions:** Add a “Quick Start” section in the README with import steps and an overview of how the score is calculated (malicious×2 + suspicious).
- [ ] **Example payload:** Provide a sample cURL command or JSON payload in `/examples/` for testing the webhook.
- [ ] **Demo GIF:** Optionally add a short GIF demonstrating the trigger → VirusTotal scan → Slack alert flow.

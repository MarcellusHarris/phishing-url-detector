#!/bin/bash
# Example test for the Phishing URL Detector webhook
curl -X POST \
  -H "Content-Type: application/json" \
  -d '{"url":"http://example.com/malicious"}' \
  https://your-n8n-instance.com/webhook/phishing-url

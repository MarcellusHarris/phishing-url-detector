## Phishing URL Detector

This n8n workflow checks a given URL against VirusTotal and posts an alert to Slack when it scores as malicious or suspicious.

### Quick Start

1. **Import the workflow:** upload `flows/phishing-url-detector.json` in n8n (Settings → Import).  
2. **Set environment variables:**
   - `VT_API_KEY` – your VirusTotal API key.  
   - `SLACK_WEBHOOK_URL` – Slack incoming webhook for notifications.

Once imported and configured, trigger the workflow either via the webhook path `/webhook/phishing-url` or from within the n8n UI. The flow normalizes the URL, submits it to VirusTotal, fetches the analysis report, calculates a simple risk score (malicious findings × 2 plus suspicious findings), and posts either a high‑risk alert or informational message to Slack.

![Phishing Detector Diagram](assets/phishing-detector-diagram.png)
